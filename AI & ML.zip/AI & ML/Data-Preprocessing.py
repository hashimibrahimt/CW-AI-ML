import pandas as pd
import numpy as np

movies_df = pd.read_csv('tmdb_5000_movies.csv')
credits_df = pd.read_csv('tmdb_5000_credits.csv')

# renaming column
credits_df.rename(columns = {'movie_id' : 'id'} , inplace = True)

# merging dataset
result_df = pd.merge(movies_df , credits_df , on = 'id')

# dropping columns : cleaning dataset
result_df.drop(['homepage', 'title_x', 'title_y', 'production_companies'] , axis = 1 , inplace = True)

# dropping cols with na
result_df.dropna(inplace = True)
# result_df.info()

# calculating weighted_rating
R = result_df['vote_average']
v = result_df['vote_count']
C = result_df['vote_average'].mean()
print(C)
m = result_df['vote_count'].quantile(0.9)
print(m)
result_df['weighted_rating'] = (R*v + C*m) / (v + m)

result_df.sort_values('weighted_rating' , ascending = False , inplace = True)

import plotly.express as px
bar_plot = px.bar(result_df.head(10).sort_values('weighted_rating') , x = 'weighted_rating' , y = 'original_title' , orientation = 'h')
# bar_plot.show()

from ast import literal_eval

features = ['cast' , 'crew', 'keywords', 'genres']
for feature in features:
  result_df[feature] = result_df[feature].apply(literal_eval)

def get_director(crew):
  for crew_member in crew:
    if crew_member['job']  ==  'Director':
      return crew_member['name']

  return np.nan

result_df['director'] = result_df['crew'].apply(get_director)


def get_name_list(column_value):
  names_list = []
  if isinstance(column_value , list):
    for element in column_value:
      names_list.append(element['name'])

  return names_list

features = ['cast' , 'keywords' , 'genres']
for feature in features:
  result_df[feature] = result_df[feature].apply(get_name_list)

def clean_data(column_value):
  modified_list = []
  modified_string = ""
  if isinstance(column_value , list):
    for element in column_value:
      modified_string = element.replace(" " , "")
      modified_list.append(modified_string.lower())

    return modified_list

  elif isinstance(column_value , str):
    modified_string = column_value.replace(" " , "")
    return modified_string.lower()

  else:
    return ''

features = ['cast' , 'keywords' , 'genres' , 'director']
for feature in features:
  result_df[feature] = result_df[feature].apply(clean_data)

def create_soup(x):
   return ' '.join(x['keywords']) + ' ' + ' '.join(x['cast']) + ' ' + x['director'] + ' ' + ' '.join(x['genres'])
result_df['soup'] = result_df.apply(create_soup, axis=1)

# resetting index
common_df = result_df.reset_index()
indices = pd.Series(common_df.index, index=common_df['original_title'])

# converting dataframe to csv
common_df.to_csv('movies.csv')