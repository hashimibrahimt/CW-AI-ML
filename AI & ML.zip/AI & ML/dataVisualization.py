import ast
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict

movies_data = pd.read_csv("movies.csv")

################################################## Visualisations #############################################################

# 1. Genre Popularity Bar Chart

# Convert 'genres' from string representations of lists to actual lists
movies_data['genres'] = movies_data['genres'].apply(ast.literal_eval)

# dictionary to accumulate genre and popularity data
genre_popularity = defaultdict(list)

# Populate the dictionary with genre and corresponding popularity
for index, row in movies_data.iterrows():
    for genre in row['genres']:
        genre_popularity[genre].append(row['popularity'])

# Calculate average popularity for each genre
genre_avg_popularity = {genre: sum(popularities) / len(popularities) for genre, popularities in genre_popularity.items()}

# Convert to DataFrame for plotting
genre_popularity_df = pd.DataFrame(list(genre_avg_popularity.items()), columns=['Genre', 'Average Popularity']).sort_values(by='Average Popularity', ascending=False)

# Plotting the genre popularity
plt.figure(figsize=(12, 8))
plt.barh(genre_popularity_df['Genre'], genre_popularity_df['Average Popularity'], color='skyblue')
plt.xlabel('Average Popularity')
plt.ylabel('Genres')
plt.title('Average Popularity of Movie Genres')
plt.gca().invert_yaxis()  # Invert y-axis to display the highest values at the top
plt.show()

# 2. Top 10 movies based on weighted rating Bar Chart

df = pd.read_csv('final.csv')

# Sorting dataframe with respect to weighted rating column
df = df.sort_values('weighted_rating', ascending=False)

# Plotting the sorted DataFrame
plt.figure(figsize=(10, 6))
plt.barh(df['original_title'].head(10), df['weighted_rating'].head(10), color='skyblue')
plt.xlabel('Weighted Rating')
plt.ylabel('Movie Title')
plt.title('Top 10 Movies by Weighted Rating')
plt.gca().invert_yaxis()  # Invert y-axis to show the highest rated movie at the top
plt.show()