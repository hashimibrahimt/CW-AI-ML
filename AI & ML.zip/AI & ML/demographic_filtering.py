import pandas as pd

df = pd.read_csv('final.csv')

# sorting dataframe : wrt to weighted rating col 
df = df.sort_values('weighted_rating' , ascending = False)

# final dataframe
output = df[['original_title' , 'poster_link' , 'runtime', 'release_date' , 'weighted_rating' ]].head(20)

